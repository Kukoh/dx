//
//  Question.swift
//  Quizzler
//
//  Created by 尹航 on 2017-10-19.
//  Copyright © 2017 London App Brewery. All rights reserved.
//

import Foundation

class Question {
    let questionText : String
    let answer : String
    
    init(text: String, correctAnswer: String) {
        questionText = text
        answer = correctAnswer
    }
    
}
