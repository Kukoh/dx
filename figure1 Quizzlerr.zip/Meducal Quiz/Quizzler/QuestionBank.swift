//
//  QuestionBank.swift
//  Quizzler
//
//  Created by 尹航 on 2017-10-19.
//  Copyright © 2017 London App Brewery. All rights reserved.
//

import Foundation

class QuestionBank {
    var list = [Question]()
    init() {
        // Creating a quiz item and appending it to the list
        let item = Question(text: "1. A young man presents to your office with intermittent fever and fatigue. On examination, he is tachycardic, but has no other findings except the new lesions on his hands shown here. The patient is a non-smoker. Lab tests demonstrate normocytic anemia and mild leukocytosis. His urinalysis is positive for blood. What diagnosis can safely be excluded? \n\nA Subacute bacterial endocarditis \nB Hand-foot-and-mouth disease \nC Secondary syphilis\nD Buerger’s disease", correctAnswer: "D")
        
        // Add the Question to the list of questions
        list.append(item)
        
        // skipping one step and just creating the quiz item inside the append function
        list.append(Question(text: "2. A dark-skinned patient presents with new complaints of ankle arthritis and of diffuse pruritus upon bathing. Upon inquiry, he mentions that he doesn’t know how long his fingernails have been dark, but it seems fairly recent. Given a suspected diagnosis of polycythemia rubra vera, which of the following treatment options are not useful at this stage? \n\nA. Phlebotomy alone\nB. Phlebotomy + iron supplementation\nC. Acetylsalicylic acid (ASA)\nD. Hydroxyurea", correctAnswer: "B"))
        
        list.append(Question(text: "3. This patient presents with painful lesions on the ear and cheek. A biopsy demonstrates leukocytoclastic vasculitis. Use of which recreational drug should be included in the patient’s history?\n\nA. Heroin\nB. Marijuana\nC. Cocaine\nD. Bath Salts", correctAnswer: "C"))
        
        list.append(Question(text: "4. A 19 year-old college student presents with a fever, submandibular lymphadenopathy, and exudative tonsillitis. Treatment is started, and within days the patient develops the exanthem. What is the most likely diagnosis?\n\nA. Strep throat\nB. Henoch-Schonlein purpura\nC. Mononucleosis\nD. Drug allergy", correctAnswer: "C"))
        
        list.append(Question(text: "5. Sigmoid volvulus is a surgical emergency. What is the most common risk factor among elderly patients?\n\nA. Colon cancer\nB. Prior bowel surgery\nC. Hirschsprung’s disease\nD. Chronic constipation", correctAnswer: "D"))
        
        list.append(Question(text: "6. This 56 year-old female developed a rash following a long car trip from Illinois to Connecticut. Aside from the reticular hyperpigmentation, the skin is otherwise normal. She complains of no itching, pain, or altered sensation. What is the most likely cause of this skin change?\n\nA. Livedo reticularis from stasis\nB. Erythema migrans from lyme disease\nC. Postinflammatory hyperpigmentation\nD. Erythema ab igne from seat warmer", correctAnswer: "D"))
        
        list.append(Question(text: "7. This 40 year-old woman with chronic filarial lymphedema presents with a soft tissue infection of the affected limb. What treatment would you prescribe?\n\nA. Antibiotics alone \nB. Antibiotics + compressive stockings\nC. Antihelminthic medications\nD. Antibiotics + topical glucocorticoids", correctAnswer: "A"))
        
        list.append(Question(text: "8. This fifty year-old female presents with acute pain, erythema, and swelling of the left leg. The patient has pain with movement and passive flexion. Given a suspicion of compartment syndrome, which of the following assessments should be performed?\n\nA. Measurement of compartment pressures\nB. Assessment of palpable arterial pulsation\nC. Capillary refill\nD. Power in dorsiflexion and plantar flexion", correctAnswer: "A"))
        
        list.append(Question(text: "9. This fifty-five year-old male visits your office with complaints of dyspnea on exertion and macroglossia. What diagnostic test is indicated?\n\nA. Bone marrow biopsy\nB. Tongue biopsy\nC. Pulmonary function tests\nD. Thyroid-stimulating hormone (TSH) test", correctAnswer: "A"))
        
    }
}
